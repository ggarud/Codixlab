const mongoose=require('mongoose')
const add =({
    Area:{ type: Number, required: true },
    street:{ type: String, required: true }
})